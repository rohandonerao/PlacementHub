import { Router } from "express";
import User from "../models/User.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = Router();

router.use(authenticate, authorize("tpo"));

router.get("/pending-students", async (req, res) => {
  try {
    const students = await User.find({
      role: "student",
      isVerified: false
    }).select("-passwordHash");

    return res.json({ students });
  } catch {
    return res.status(500).json({ message: "Failed to fetch pending students." });
  }
});

router.patch("/students/:id/approve", async (req, res) => {
  try {
    const student = await User.findOneAndUpdate(
      { _id: req.params.id, role: "student", isVerified: false },
      { isVerified: true },
      { new: true, runValidators: true }
    ).select("-passwordHash");

    if (!student) {
      return res.status(404).json({
        message: "Pending student not found."
      });
    }

    return res.json({
      message: "Student approved successfully.",
      student
    });
  } catch {
    return res.status(400).json({ message: "Invalid student ID." });
  }
});

router.patch("/students/:id/reject", async (req, res) => {
  try {
    const student = await User.findOneAndDelete({
      _id: req.params.id,
      role: "student",
      isVerified: false
    }).select("-passwordHash");

    if (!student) {
      return res.status(404).json({
        message: "Pending student not found."
      });
    }

    return res.json({
      message: "Student registration rejected.",
      student
    });
  } catch {
    return res.status(400).json({ message: "Invalid student ID." });
  }
});

export default router;