import express from "express";
import mongoose from "mongoose";
import User from "../models/User.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = express.Router();

router.get(
  "/pending",
  authenticate,
  authorize("tpo", "admin"),
  async (req, res) => {
    try {
      const students = await User.find({
        role: "student",
        isVerified: false
      })
        .select("-passwordHash")
        .sort({ createdAt: -1 })
        .lean();

      return res.status(200).json(students);
    } catch (error) {
      console.error("Fetch pending students error:", error);

      return res.status(500).json({
        message: "Failed to fetch pending students."
      });
    }
  }
);

router.get(
  "/",
  authenticate,
  authorize("tpo", "admin"),
  async (req, res) => {
    try {
      const students = await User.find({
        role: "student"
      })
        .select("-passwordHash")
        .sort({ createdAt: -1 })
        .lean();

      return res.status(200).json(students);
    } catch (error) {
      console.error("Fetch students error:", error);

      return res.status(500).json({
        message: "Failed to fetch students."
      });
    }
  }
);

router.patch(
  "/:studentId/approve",
  authenticate,
  authorize("tpo", "admin"),
  async (req, res) => {
    try {
      const { studentId } = req.params;

      if (!mongoose.isValidObjectId(studentId)) {
        return res.status(400).json({
          message: "Invalid student ID."
        });
      }

      const student = await User.findOneAndUpdate(
        {
          _id: studentId,
          role: "student",
          isVerified: false
        },
        {
          $set: { isVerified: true }
        },
        {
          new: true,
          runValidators: true
        }
      ).select("-passwordHash");

      if (!student) {
        return res.status(404).json({
          message: "Pending student not found."
        });
      }

      return res.status(200).json({
        message: "Student approved successfully.",
        student
      });
    } catch (error) {
      console.error("Approve student error:", error);

      return res.status(500).json({
        message: "Failed to approve student."
      });
    }
  }
);

router.patch(
  "/:studentId/reject",
  authenticate,
  authorize("tpo", "admin"),
  async (req, res) => {
    try {
      const { studentId } = req.params;

      if (!mongoose.isValidObjectId(studentId)) {
        return res.status(400).json({
          message: "Invalid student ID."
        });
      }

      const student = await User.findOneAndDelete({
        _id: studentId,
        role: "student",
        isVerified: false
      });

      if (!student) {
        return res.status(404).json({
          message: "Pending student not found."
        });
      }

      return res.status(200).json({
        message: "Student registration rejected successfully."
      });
    } catch (error) {
      console.error("Reject student error:", error);

      return res.status(500).json({
        message: "Failed to reject student registration."
      });
    }
  }
);

export default router;