import express from "express";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import User from "../models/User.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = express.Router();
router.use(authenticate, authorize("admin"));

const publicTpoFields = "name email role department phone college isVerified isActive createdAt updatedAt";

router.get("/tpos", async (req, res) => {
  try {
    const tpos = await User.find({ role: "tpo" }).select(publicTpoFields).sort({ createdAt: -1 }).lean();
    return res.json({ tpos });
  } catch (error) {
    return res.status(500).json({ message: "Unable to load TPO accounts." });
  }
});

router.post("/tpos", async (req, res) => {
  try {
    const { name, email, password, department = "", phone = "", college = "" } = req.body;
    if (!name?.trim() || !email?.trim() || !password) {
      return res.status(400).json({ message: "Name, email and password are required." });
    }
    if (password.length < 8) {
      return res.status(400).json({ message: "Password must contain at least 8 characters." });
    }
    const normalizedEmail = email.trim().toLowerCase();
    if (await User.findOne({ email: normalizedEmail })) {
      return res.status(409).json({ message: "An account with this email already exists." });
    }
    const passwordHash = await bcrypt.hash(password, 12);
    const tpo = await User.create({
      name: name.trim(), email: normalizedEmail, passwordHash, role: "tpo",
      department, phone, college, isVerified: true, isActive: true
    });
    return res.status(201).json({ message: "TPO account created successfully.", tpo: await User.findById(tpo._id).select(publicTpoFields).lean() });
  } catch (error) {
    if (error.code === 11000) return res.status(409).json({ message: "An account with this email already exists." });
    return res.status(500).json({ message: "Unable to create TPO account." });
  }
});

router.patch("/tpos/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) return res.status(400).json({ message: "Invalid TPO account ID." });
    const { name, email, department = "", phone = "", college = "" } = req.body;
    if (!name?.trim() || !email?.trim()) return res.status(400).json({ message: "Name and email are required." });
    const normalizedEmail = email.trim().toLowerCase();
    const duplicate = await User.findOne({ email: normalizedEmail, _id: { $ne: id } });
    if (duplicate) return res.status(409).json({ message: "An account with this email already exists." });
    const tpo = await User.findOneAndUpdate(
      { _id: id, role: "tpo" },
      { $set: { name: name.trim(), email: normalizedEmail, department, phone, college } },
      { new: true, runValidators: true }
    ).select(publicTpoFields).lean();
    if (!tpo) return res.status(404).json({ message: "TPO account not found." });
    return res.json({ message: "TPO account updated successfully.", tpo });
  } catch (error) {
    if (error.code === 11000) return res.status(409).json({ message: "An account with this email already exists." });
    return res.status(500).json({ message: "Unable to update TPO account." });
  }
});

router.patch("/tpos/:id/status", async (req, res) => {
  try {
    const { id } = req.params;
    const { isActive } = req.body;
    if (!mongoose.isValidObjectId(id)) return res.status(400).json({ message: "Invalid TPO account ID." });
    if (typeof isActive !== "boolean") return res.status(400).json({ message: "isActive must be true or false." });
    const tpo = await User.findOneAndUpdate(
      { _id: id, role: "tpo" }, { $set: { isActive } }, { new: true }
    ).select(publicTpoFields).lean();
    if (!tpo) return res.status(404).json({ message: "TPO account not found." });
    return res.json({ message: `TPO account ${isActive ? "activated" : "deactivated"} successfully.`, tpo });
  } catch (error) {
    return res.status(500).json({ message: "Unable to update TPO account status." });
  }
});

export default router;
