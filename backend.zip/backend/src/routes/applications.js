import express from "express";
import mongoose from "mongoose";
import Application from "../models/Application.js";
import PlacementDrive from "../models/PlacementDrive.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = express.Router();

router.post(
  "/:driveId",
  authenticate,
  authorize("student"),
  async (req, res) => {
    try {
      const { driveId } = req.params;

      if (!mongoose.isValidObjectId(driveId)) {
        return res.status(400).json({
          message: "Invalid placement drive ID."
        });
      }

      const drive = await PlacementDrive.findById(driveId);

      if (!drive) {
        return res.status(404).json({
          message: "Placement drive not found."
        });
      }

      if (
        drive.status !== "open" ||
        new Date(drive.applicationDeadline).getTime() < Date.now()
      ) {
        return res.status(400).json({
          message: "This placement drive is closed."
        });
      }

      const student = req.user;

      const existingApplication = await Application.findOne({
        student: student._id,
        drive: drive._id
      });

      if (existingApplication) {
        return res.status(409).json({
          message: "You have already applied for this placement drive."
        });
      }

      const checks = [
        {
          criterion: "Minimum CGPA",
          required: drive.minimumCgpa,
          actual: student.cgpa,
          passed:
            student.cgpa != null &&
            Number.isFinite(Number(student.cgpa)) &&
            Number(student.cgpa) >= Number(drive.minimumCgpa)
        },
        {
          criterion: "Maximum Backlogs",
          required: drive.maximumBacklogs,
          actual: student.backlogs,
          passed:
            student.backlogs != null &&
            Number.isFinite(Number(student.backlogs)) &&
            Number(student.backlogs) <= Number(drive.maximumBacklogs)
        }
      ];

      if (drive.eligibleDepartments?.length > 0) {
        checks.push({
          criterion: "Eligible Department",
          required: drive.eligibleDepartments,
          actual: student.department,
          passed:
            typeof student.department === "string" &&
            drive.eligibleDepartments.some(
              department =>
                department.trim().toLowerCase() ===
                student.department.trim().toLowerCase()
            )
        });
      }

      if (drive.eligibleGraduationYears?.length > 0) {
        const eligibleYears = drive.eligibleGraduationYears.map(Number);

        checks.push({
          criterion: "Graduation Year",
          required: eligibleYears,
          actual: student.graduationYear,
          passed:
            student.graduationYear != null &&
            Number.isFinite(Number(student.graduationYear)) &&
            eligibleYears.includes(Number(student.graduationYear))
        });
      }

      const failedChecks = checks.filter(check => !check.passed);

      if (failedChecks.length > 0) {
        return res.status(403).json({
          message: "You are not eligible for this placement drive.",
          failedChecks
        });
      }

      const application = await Application.create({
        student: student._id,
        drive: drive._id
      });

      return res.status(201).json({
        message: "Application submitted successfully.",
        application
      });
    } catch (error) {
      if (error.code === 11000) {
        return res.status(409).json({
          message: "You have already applied for this placement drive."
        });
      }

      console.error("Application submission error:", error);

      return res.status(500).json({
        message: "Failed to submit application."
      });
    }
  }
);

router.get(
  "/student/my-applications",
  authenticate,
  authorize("student"),
  async (req, res) => {
    try {
      const applications = await Application.find({
        student: req.user._id
      })
        .populate(
          "drive",
          "companyName jobTitle packageLPA applicationDeadline status"
        )
        .sort({ appliedAt: -1 })
        .lean();

      return res.status(200).json(applications);
    } catch (error) {
      console.error("Fetch student applications error:", error);

      return res.status(500).json({
        message: "Failed to fetch applications."
      });
    }
  }
);

router.get(
  "/drive/:driveId",
  authenticate,
  authorize("tpo", "admin"),
  async (req, res) => {
    try {
      const { driveId } = req.params;

      if (!mongoose.isValidObjectId(driveId)) {
        return res.status(400).json({
          message: "Invalid placement drive ID."
        });
      }

      const drive = await PlacementDrive.findById(driveId);

      if (!drive) {
        return res.status(404).json({
          message: "Placement drive not found."
        });
      }

      const applications = await Application.find({
        drive: driveId
      })
        .populate(
          "student",
          "name email department cgpa backlogs graduationYear skills"
        )
        .sort({ appliedAt: -1 })
        .lean();

      return res.status(200).json(applications);
    } catch (error) {
      console.error("Fetch drive applications error:", error);

      return res.status(500).json({
        message: "Failed to fetch applications."
      });
    }
  }
);

router.patch(
  "/:applicationId/status",
  authenticate,
  authorize("tpo", "admin"),
  async (req, res) => {
    try {
      const { applicationId } = req.params;
      const { status } = req.body;

      if (!mongoose.isValidObjectId(applicationId)) {
        return res.status(400).json({
          message: "Invalid application ID."
        });
      }

      const allowedStatuses = [
        "shortlisted",
        "rejected",
        "selected"
      ];

      if (!allowedStatuses.includes(status)) {
        return res.status(400).json({
          message: "Status must be shortlisted, rejected, or selected."
        });
      }

      const application = await Application.findByIdAndUpdate(
        applicationId,
        { status },
        { new: true, runValidators: true }
      );

      if (!application) {
        return res.status(404).json({
          message: "Application not found."
        });
      }

      return res.status(200).json({
        message: "Application status updated successfully.",
        application
      });
    } catch (error) {
      console.error("Update application status error:", error);

      return res.status(500).json({
        message: "Failed to update application status."
      });
    }
  }
);

export default router;