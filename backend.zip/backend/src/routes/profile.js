import { Router } from "express";
import User from "../models/User.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = Router();

router.use(authenticate, authorize("student"));

router.get("/", async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select("-passwordHash");

    if (!user) {
      return res.status(404).json({ message: "Profile not found." });
    }

    return res.json({ user });
  } catch {
    return res.status(500).json({ message: "Failed to fetch profile." });
  }
});

router.put("/", async (req, res) => {
  try {
    const { name, department, phone, college, graduationYear, cgpa, backlogs, skills } = req.body;

    if (name !== undefined && !name.trim()) {
      return res.status(400).json({ message: "Name cannot be empty." });
    }

    if (cgpa !== undefined && cgpa !== null && (typeof cgpa !== "number" || cgpa < 0 || cgpa > 10)) {
      return res.status(400).json({ message: "CGPA must be between 0 and 10." });
    }

    if (backlogs !== undefined && (!Number.isInteger(backlogs) || backlogs < 0)) {
      return res.status(400).json({ message: "Backlogs must be a non-negative integer." });
    }

    if (graduationYear !== undefined && graduationYear !== null && (!Number.isInteger(graduationYear) || graduationYear < 2000 || graduationYear > 2100)) {
      return res.status(400).json({ message: "Enter a valid graduation year." });
    }

    if (skills !== undefined && (!Array.isArray(skills) || !skills.every(skill => typeof skill === "string"))) {
      return res.status(400).json({ message: "Skills must be a list of text values." });
    }

    const updates = {};

    for (const field of ["name", "department", "phone", "college"]) {
      if (req.body[field] !== undefined) {
        updates[field] = typeof req.body[field] === "string"
          ? req.body[field].trim()
          : req.body[field];
      }
    }

    for (const field of ["graduationYear", "cgpa", "backlogs"]) {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field] === "" ? null : req.body[field];
      }
    }

    if (skills !== undefined) {
      updates.skills = skills.map(skill => skill.trim()).filter(Boolean);
    }

    const user = await User.findOneAndUpdate(
      { _id: req.user._id, role: "student" },
      { $set: updates },
      { new: true, runValidators: true }
    ).select("-passwordHash");

    if (!user) {
      return res.status(404).json({ message: "Profile not found." });
    }

    return res.json({ message: "Profile updated successfully.", user });
  } catch {
    return res.status(400).json({ message: "Could not update profile. Check your field values." });
  }
});

export default router;