
import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ["student", "tpo", "admin"], default: "student" },
  department: { type: String, default: "" },
  phone: { type: String, default: "" },
  college: { type: String, default: "" },
  graduationYear: { type: Number, default: null },
  cgpa: { type: Number, min: 0, max: 10, default: null },
  backlogs: { type: Number, min: 0, default: 0 },
  skills: { type: [String], default: [] },
  isVerified: { type: Boolean, default: false },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

export default mongoose.model("User", userSchema);
